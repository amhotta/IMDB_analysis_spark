#! /usr/local/bin/python
import sys
import os
import subprocess
import configparser
import requests
import hmac
import hashlib
import base64
import xml.etree.ElementTree as ET
from datetime import date
import datetime
import argparse
from dateutil.relativedelta import relativedelta
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import traceback
import re

def run_cmd(args_list):
    print('Running system command: {0}'.format(' '.join(args_list)))
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    s_output, s_err = proc.communicate()
    s_return = proc.returncode
    return s_return, s_output, s_err


def get_hdfs_file(HDFS_BIN_PATH, fileName, hdfs_location, checker):
    localFile = os.path.basename(fileName)
    if os.path.isfile(fileName):
        print(fileName + " already exists. Ignore HDFS get")
    else:
        try:
            (ret, out, err) = run_cmd([HDFS_BIN_PATH, 'dfs', '-get', hdfs_location])
        except Exception as e:
            print("Printing Exception1 below:")
            print(e)
            pass
    if checker and not os.path.isfile(localFile):
        print("HDFS Get failed to download config file. Exiting...")
        sys.exit(-1)
    return localFile


def readConfig(configFile):
    try:
        confParser = configparser.RawConfigParser(allow_no_value=True)
        confParser.read(configFile)
        return confParser
    except Exception as e:
        print("Error: readConfig() was not successful:[configFile=" + configFile + "]")
        print(e)
        sys.exit(-1)


def send_error_mail(errInfo, application, emailTo, emailFrom, smtpServer, flag="ERROR"):
    BODY = errInfo
    SUBJECT = "{0}: Notification Email for {1} process".format(flag, application)
    msg = MIMEMultipart()
    msg['Subject'] = SUBJECT
    TO = emailTo.split(',')
    msg.preamble = 'Multipart message.\n'
    try:
        print("EMAIL PROCESS STARTED")
        server = smtplib.SMTP(smtpServer)
        msg.attach(MIMEText(BODY, 'plain'))
        server.sendmail(emailFrom, TO, msg.as_string())
    except smtplib.SMTPException as e:
        print("Error: unable to send Error email with attachment", e)
        sys.exit(1)


def purge_older_blobs_in_container(accessKey, storageAccountName, storageAccountUrl,
                                   containerName, azureApiversion, purgePeriodInYears):
    errors = ""
    isError = False
    headers = create_signature_for_listing_container(azureApiversion, storageAccountName, accessKey, containerName)

    url = ('https://' + storageAccountUrl + '/' + containerName)
    payload = {'comp': 'list', 'restype': 'container'}
    r = requests.get(url, headers=headers, params=payload)
    if r.status_code != 200:
        isError = True
        error = "Error:Azure blob storage rest API call not succeeded:[statusCode=" + str(
            r.status_code) + "," + "response:" + r.text + "]"
        errors = errors + error + "\n"
        print(error)
    else:
        myroot = ET.fromstring(r.text)
        blobs = []
        for y in myroot.findall('Blobs'):
            for z in y.findall('Blob'):
                for a in z.findall("Properties"):
                    for c in a:
                        if c.tag == 'Content-Length':
                            if int(c.text) > 0:
                                blobs.append(z.find('Name').text)
        for blb in blobs:
            blbDate = getPartitionDate(blb)
            encodedUrl = blb.replace(" ", "%20")
            if blbDate != None:
                purgeTimeObj = (date.today() - relativedelta(years=purgePeriodInYears))
                if blbDate < purgeTimeObj:
                    print("purging:" + blb)
                    headers = create_signature_for_purging_blobs(blb, azureApiversion, storageAccountName, accessKey,
                                                             containerName)
                    purgeUrl = url + "/" + encodedUrl
                    print(purgeUrl)
                    r = requests.delete(purgeUrl, headers=headers)
                    if r.status_code != 202:
                        isError = True
                        error = "Error:Azure blob storage rest API call not succeeded:[statusCode=" + str(
                            r.status_code) + "," + "response:" + r.text + "]"
                        errors = errors + error + "\n"
                        print(error)
                    else:
                        print("Purge blob succeeded:[purgeUrl=" + purgeUrl + "," + "blob=" + blb + "]")
            else:
                print("encountered unknown partition [blb=" + blb + "]")
    return isError, errors

def getPartitionDate(blb):
    splits = blb.split("=")
    bldDate = re.findall(r"[0-9]{8}", splits[1])
    if len(bldDate) == 0:
        bldDate = re.findall(r"[0-9]{4}", splits[1])

    if len(bldDate) == 1:
        partitionDate = bldDate[0]
        print(partitionDate)
        if len(partitionDate) == 8:
            blbDateObj = datetime.datetime.strptime(partitionDate, '%Y%m%d').date()
            print(blbDateObj)
            return blbDateObj
        elif len(partitionDate) == 6:
            partitionDate = partitionDate + '31'
            blbDateObj = datetime.datetime.strptime(partitionDate, '%Y%m%d').date()
            return blbDateObj
    return None


def create_signature_for_listing_container(apiVersion, storageAccountName, accessKey, containerName):
    request_time = datetime.datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')

    string_params = {
        'verb': 'GET',
        'Content-Encoding': '',
        'Content-Language': '',
        'Content-Length': '',
        'Content-MD5': '',
        'Content-Type': '',
        'Date': '',
        'If-Modified-Since': '',
        'If-Match': '',
        'If-None-Match': '',
        'If-Unmodified-Since': '',
        'Range': '',
        'CanonicalizedHeaders': 'x-ms-date:' + request_time + '\nx-ms-version:' + apiVersion + '\n',
        'CanonicalizedResource': '/' + storageAccountName + '/' + containerName + "\n" + "comp:list" + "\n"
                                 + "restype:container"
    }

    string_to_sign = (string_params['verb'] + '\n'
                      + string_params['Content-Encoding'] + '\n'
                      + string_params['Content-Language'] + '\n'
                      + string_params['Content-Length'] + '\n'
                      + string_params['Content-MD5'] + '\n'
                      + string_params['Content-Type'] + '\n'
                      + string_params['Date'] + '\n'
                      + string_params['If-Modified-Since'] + '\n'
                      + string_params['If-Match'] + '\n'
                      + string_params['If-None-Match'] + '\n'
                      + string_params['If-Unmodified-Since'] + '\n'
                      + string_params['Range'] + '\n'
                      + string_params['CanonicalizedHeaders']
                      + string_params['CanonicalizedResource'])

    signed_string = base64.b64encode(hmac.new(base64.b64decode(accessKey), msg=string_to_sign.encode('utf-8'),
                                              digestmod=hashlib.sha256).digest()).decode()

    headers = {
        'x-ms-version': apiVersion,
        'x-ms-date': request_time,
        'Authorization': ('SharedKey ' + storageAccountName + ':' + signed_string)
    }

    return headers


def create_signature_for_purging_blobs(blb, apiVersion, storageAccountName, accessKey, containerName):
    request_time = datetime.datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
    encodedUrl = blb.replace(" ", "%20")
    string_params = {
        'verb': 'DELETE',
        'Content-Encoding': '',
        'Content-Language': '',
        'Content-Length': '',
        'Content-MD5': '',
        'Content-Type': '',
        'Date': '',
        'If-Modified-Since': '',
        'If-Match': '',
        'If-None-Match': '',
        'If-Unmodified-Since': '',
        'Range': '',
        'CanonicalizedHeaders': 'x-ms-date:' + request_time + '\nx-ms-version:' + apiVersion + '\n',
        'CanonicalizedResource': '/' + storageAccountName + '/' + containerName + "/" + encodedUrl
    }

    string_to_sign = (string_params['verb'] + '\n'
                      + string_params['Content-Encoding'] + '\n'
                      + string_params['Content-Language'] + '\n'
                      + string_params['Content-Length'] + '\n'
                      + string_params['Content-MD5'] + '\n'
                      + string_params['Content-Type'] + '\n'
                      + string_params['Date'] + '\n'
                      + string_params['If-Modified-Since'] + '\n'
                      + string_params['If-Match'] + '\n'
                      + string_params['If-None-Match'] + '\n'
                      + string_params['If-Unmodified-Since'] + '\n'
                      + string_params['Range'] + '\n'
                      + string_params['CanonicalizedHeaders']
                      + string_params['CanonicalizedResource'])

    signed_string = base64.b64encode(hmac.new(base64.b64decode(accessKey), msg=string_to_sign.encode('utf-8'),
                                              digestmod=hashlib.sha256).digest()).decode()
    headers = {
        'x-ms-version': apiVersion,
        'x-ms-date': request_time,
        'Authorization': ('SharedKey ' + storageAccountName + ':' + signed_string)
    }

    return headers

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # Required Arguments
    parser.add_argument('-e', '--environment', dest='environment', help='environment', nargs='+')
    parser.add_argument('-c', '--config-file', dest='configFile', help='config file location', nargs='+')

    results = parser.parse_args()

    if results.environment is None or results.configFile is None :
        parser.print_help()
        sys.exit(-1)

    configFile = results.configFile[0]
    environment = results.environment[0]

    HADOOP_BIN_PATH = '/usr/bin/hadoop'
    HDFS_BIN_PATH = '/us/bin/hdfs'
    configFileName = configFile.split('/')[-1]

    # /ez/data/wss/aradretention/azure_blob_purge/azure_blob_purge.config
    configFile = get_hdfs_file(HDFS_BIN_PATH, configFileName, configFile, 1)
    config = readConfig(configFile)

    storageAccount = config[environment]['storageAccount']
    storageAccountName = config[environment]['storageAccountName']
    storageAccountKey = config[environment]['storageAccountKey']
    storageContainer = config[environment]['storageContainer']
    purgePeriodInYears = int(config[environment]['purgePeriodInYears'])
    emailFrom = config[environment]['emailFrom']
    emailTo = config[environment]['emailTo']
    smtpServer = config[environment]['smtpServer']
    appName = config[environment]['appName']
    subPrefix = config[environment]['subPrefix']
    azureApiversion = config[environment]['azureApiversion']

    isError, errors = purge_older_blobs_in_container(storageAccountKey, storageAccountName, storageAccount,
                                                     storageContainer,
                                                     azureApiversion, purgePeriodInYears)
    if isError:
        errorMsg = "There are failures in during purging of Azure blobs"
        print("sending error email to:[emailTo=" + emailTo + "]")
        send_error_mail(errors, appName, emailTo, emailFrom, smtpServer)