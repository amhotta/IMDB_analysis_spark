#! /usr/local/bin/python

import argparse
import subprocess
import sys
from datetime import date, timedelta

import requests
import logging
import os
import configparser
import time
import smtplib, traceback
from email.mime.multipart import MIMEMultipart from email.mime.text import MIMEText from impala.dbapi import connect

def dropPartitions(conn, tableName, dbRep, partitionToDrop):
    print("dropping  partition:[tableName=" + tableName + ", partitionToDrop=" + partitionToDrop + ", dbRep=" + dbRep + "]")
    sqlQuery = "ALTER TABLE" + " " + dbRep + "." + tableName + " " + "DROP IF EXISTS PARTITION(" + partitionToDrop + ")"
    try:
        iCursor = conn.cursor()
        iCursor.execute("set max_row_size=8mb")
        iCursor.execute(sqlQuery)
    except:
        emsg = "Error: Impala drop partition failed [table=" +tableName+ ", dbRep=" + dbRep + ", partition=" +  partitionToDrop + ", error=" + traceback.format_exc() +  "]"
        print(emsg)
        raise Exception(emsg)

def delete_hdfs_folder(HDFS_BIN_PATH, hdfsPath):
    (ret, out, err) = run_cmd([HDFS_BIN_PATH, 'dfs', '-rmr', hdfsPath])
    if ret == 0:
        print("successfully deleted hdfs folder :" + hdfsPath)
    else:
        print("error while deleting hdfs folder:[hdfsPath="+hdfsPath + ", error=" + err.decode("utf-8") + "]")

def impRefresh(tbl,conn, dbRep):
  try:
    iCursor = conn.cursor()
    iCursor.execute("set max_row_size=8mb")
    iCursor.execute("refresh "+ dbRep +"."+ tbl)
  except:
    emsg = "Error: Impala refresh for " +tbl+" table was not successful. "+ traceback.format_exc()
    print(emsg)
    raise Exception(emsg)

def fetch_azure_blob_info(schemaName, tableName, partitionName, fileName, storageAccount, storageContainer):
    azure_storage_api_base_url = "https://" + storageAccount + "/" + storageContainer
    url = azure_storage_api_base_url + "/" + schemaName + "/" + tableName + "/" + partitionName + "/" + fileName
    response = requests.get(url)
    print("Fetched azure blob info[url=" + url + "," + "response :" + str(response.status_code) + "]")
    if response.status_code != 200:
        return -1;
    else:
        return int(response.headers['Content-Length'])

def fetch_partitions_older_than(partition_names, todaysPartition):
    print("fetching partitions older than:" + todaysPartition)
    partitions_to_drop = []
    for partitionName in partition_names:
        if len(partitionName) < 6:
                 parition_name = partitionName + "31"
        else:
                parition_name = partitionName
        if(parition_name <= todaysPartition):
                partitions_to_drop.append(partitionName)
    return partitions_to_drop


def backup_to_adls(HADOOP_BIN_PATH, partitionPath, partitionName, schemaName, tableName, storageAccountKey, storageAccount, containerName, num_mappers, azjars):
    azurePath = "wasb://" + containerName + "@" + storageAccount + "/" + schemaName + "/" + tableName + "/" + partitionName
    startTime = time.time()
    print("backing up partition to adls started [partitionName=:" + partitionName + ", table=" + tableName + ", schemaName=" + schemaName + ", hdfsPath=" + partitionPath + ",azurePath=" + azurePath + "]")

    (ret, out, err) = run_cmd(
            [HADOOP_BIN_PATH, 'distcp', '-Dfs.AbstractFileSystem.wasb.Impl=org.apache.hadoop.fs.azure.Wasb',
             '-Dfs.azure.account.key.' + storageAccount + '=' + storageAccountKey, '-libjars',
             azjars, '-m', num_mappers,
             partitionPath, azurePath])
    endTime = time.time()
    if ret == 0:
        print("backing up partition to adls completed successfully [partitionName=:" + partitionName + ", table=" + tableName + ", hdfsPath=" + partitionPath + ",azurePath=" + azurePath +
              ",timeTookInSecs=" + str((endTime-startTime)) + "]")
    else:
        print("error while copying using distcp [partitionName=:" + partitionName + ", table=" + tableName + ", hdfsPath=" + partitionPath + ",azurePath=" + azurePath + ", error=" + err.decode("utf-8") + "]")

def get_fileInfo_on_hdfs(HDFS_BIN_PATH, hdfsPath):
    files_info = []
    (ret, out, err) = run_cmd([HDFS_BIN_PATH, 'dfs', '-ls', hdfsPath])
    if ret == 0:
        lines = out.decode("utf-8").split('\n')
        for line in lines:
            if line.find(hdfsPath) != -1:
                cleansed = ' '.join(line.split())
                size = cleansed.split(" ")[4];
                file_name = os.path.basename(cleansed)
                file_info = {}
                file_info['name'] = file_name
                file_info['size'] = size
                files_info.append(file_info)
    else:
        print("error while getting files information  from hdfs path [hdfsPath=" + hdfsPath + ", error=" + err.decode("utf-8") + "]")
    return files_info

def run_cmd(args_list):
    logging.info('Running system command: {0}'.format(' '.join(args_list)))
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    s_output, s_err = proc.communicate()
    s_return = proc.returncode
    return s_return, s_output, s_err

def createTableList(out):
    lines = out.decode("utf-8").split('\n')
    tablesList = []
    for line in lines:
        splits = line.strip().split("=")
        if len(splits) > 1:
            tableConf = {}
            schemaTable = splits[0]
            print(schemaTable)
            print(schemaTable.split(","))
            tableConf['name'] = schemaTable.split(",")[0]
            tableConf['partition'] = schemaTable.split(",")[1]
            tableConf['schema'] = schemaTable.split(",")[2]
            tableConf['hdfs_location'] = splits[1]
            tablesList.append(tableConf)
    return  tablesList


def fetch_partitions(HDFS_BIN_PATH, table):
    print("hdfs_loc:" + table['hdfs_location'])
    partition_names = []
    (ret, out, err) = run_cmd([HDFS_BIN_PATH, 'dfs', '-ls', table['hdfs_location']])
    if ret == 0:
        print("retcode success")
        paritions = out.decode("utf-8").split('\n')
        print("log:")
        print(paritions)
        print("log end:")
        for parition in paritions:
            prefix = table['partition'] + "="
            print("prefix:"+prefix)
            if parition.find(prefix) != -1:
                datetimepart=parition.split("=")[1]
                parition_name = prefix + datetimepart
                partition_names.append(parition_name)
        partition_names.sort()
        print(partition_names)
    else:
        print("error during partition fetch")
        print("There is an error during listing partitions:" + err.decode("utf-8"))
    return partition_names

def read_hdfs_file(HDFS_BIN_PATH, hdfs_location) :
    print('hdfs_location:'+hdfs_location)
    (ret, out, err)= run_cmd([HDFS_BIN_PATH, 'dfs', '-cat', hdfs_location])
    print(ret)
    if ret == 0:
        return (ret, out, err)
    else:
        logging.error("There is an error during config file read:" + err.strip().decode("utf-8"))
        sys.exit(-1)

def get_hdfs_file(HDFS_BIN_PATH, fileName, hdfs_location, checker) :
    localFile = os.path.basename(fileName)
    if os.path.isfile(fileName):
        print(fileName + " already exists. Ignore HDFS get")
    else:
        try:
            (ret, out, err) = run_cmd([HDFS_BIN_PATH, 'dfs', '-get', hdfs_location])
        except Exception as e:
            print("Printing Exception1 below:")
            print(e)
            pass
    if checker and not os.path.isfile(localFile):
        print("HDFS Get failed to download config file. Exiting...")
        sys.exit(-1)
    return localFile

def backup_table_partitions(HDFS_BIN_PATH, HADOOP_BIN_PATH, table, purgePeriodInYears, storageAccount, storageAccountKey, storageContainer, num_mappers, azjars, conn) :
    print("************************* working on table:" +  table['schema'] + "." + table['name'] + " ******************************************")
    tableStartTime = time.time()
    partition_names = fetch_partitions(HDFS_BIN_PATH, table)
    partition_older = table['partition'] + "=" + (date.today() - timedelta(days=purgePeriodInYears*365)).strftime("%Y%m%d")
    print("partition_older:" + partition_older)
    partitions_to_drop = fetch_partitions_older_than(partition_names, partition_older)
    for partition_to_drop in partitions_to_drop:
        hdfsPath = table['hdfs_location'] + "/" + partition_to_drop
        backup_to_adls(HADOOP_BIN_PATH, hdfsPath, partition_to_drop, table['schema'], table['name'], storageAccountKey, storageAccount, storageContainer, num_mappers, azjars)
        files_info_on_hdfs = get_fileInfo_on_hdfs(HDFS_BIN_PATH, hdfsPath)
        for file_info in files_info_on_hdfs:
            print(file_info['name'])
            hdfs_file_size = int(file_info['size'])
            retVal = fetch_azure_blob_info(table['schema'], table['name'], partition_to_drop, file_info['name'], storageAccount, storageContainer)
            if retVal == -1:
                errMsg = "distcp failed for [table=" + table['schema'] + "." + table['name'] + ", partition:" + partition_to_drop + ", file_name:" + file_info['name'] + ", hdfspath=" + hdfsPath + "]"
                print(errMsg)
                raise Exception(errMsg)
            elif retVal == hdfs_file_size:
                print("distcp success for [table=" + table['schema'] + "." + table['name']  + ", partition:" + partition_to_drop + ", file_name:" + file_info['name'] + ", hdfspath=" + hdfsPath + ", hdfs_file_size=" + str(hdfs_file_size) +
                      ", azure_file_size=" + str(retVal) + "]")
                dropPartitions(conn, table['name'], table['schema'], partition_to_drop)
                delete_hdfs_folder(HDFS_BIN_PATH, hdfsPath)
                impRefresh(table['name'], conn, table['schema'])
            else:
                errMsg = "distcp success but size on hdfs not matching with azure [table=" + table['name'] + ", partition:" + partition_to_drop + ", file_name:" + file_info['name'] + ", hdfspath=" + hdfsPath + ", hdfs_file_size=" + str(hdfs_file_size) + ", azure_file_size=" + str(retVal) + "]"
                print(errMsg)
                raise Exception(errMsg)

        tableEndTime = time.time()
        print("************* Total time taken to copy [table=" + table['schema'] + "." + table['name']  + ", timeInSeconds=" + str(tableEndTime-tableStartTime)  + "]" + " *******************")


def readConfig(configFile):
    try:
        confParser = configparser.RawConfigParser(allow_no_value=True)
        confParser.read(configFile)
        return confParser
    except Exception as e:
        print("Error: readConfig() was not successful:[configFile=" + configFile + "]")
        print(e)
        sys.exit(-1)

# Function to send the error email.
def send_error_mail(errInfo, application, emailTo, emailFrom, smtpServer, flag="ERROR"):
    BODY = errInfo
    SUBJECT = "{0}: Notification Email for {1} process".format(flag, application)
    msg = MIMEMultipart()
    msg['Subject'] = SUBJECT
    TO = emailTo.split(',')
    msg.preamble = 'Multipart message.\n'
    try:
        print("EMAIL PROCESS STARTED")
        server = smtplib.SMTP(smtpServer)
        msg.attach(MIMEText(BODY, 'plain'))
        server.sendmail(emailFrom, TO, msg.as_string())
    except smtplib.SMTPException as e:
        print("Error: unable to send Error email with attachment", e)
        sys.exit(1)

def incidentCreation(message, recipient, subjectPrefix, environment, script, incGenerator, incAssignGroup):
    subject = subjectPrefix  + " Script: " + script + " Environment: " + environment
    sender = "no-reply@datascience.west.com"
    message = "From: <" + sender + ">\nTo: <" +  recipient + ">\nSubject: " + subject + "\n\n" + message

    try:
            cmd = "./" + incGenerator + " -g '" + incAssignGroup + "' -e '" + recipient + \
                    "' -s '" + subject + "' -d '" + subject + ". Check email for more details on errors' -V"
            (ret, out, err) = run_cmd([cmd])

            if ret == 0:
                print("INFO - Successfully generated an incident")
            else:
                print("ERROR - Unable to generate incident.\n" + str(ret))
    except:
        emsg =  traceback.format_exc()
        print("ERROR -  Unable to send email because of :" + emsg)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # Required Arguments
    parser.add_argument('-c', '--config-file',  dest = 'configFile', help='config file location', nargs='+')
    parser.add_argument('-e', '--envrionment',  dest = 'environment', help='environment', nargs='+')

    results = parser.parse_args()

    if results.configFile is None or results.environment is None:
        parser.print_help()
        sys.exit(-1)

    configFile = results.configFile[0]
    environment = results.environment[0]

    if environment != 'PREPROD' and environment != 'PROD':
        print("unknown environment")
        sys.exit(-1)

    print("script running in :" + environment + " environment")

    HADOOP_BIN_PATH = '/usr/bin/hadoop'
    HDFS_BIN_PATH = '/usr/bin/hdfs'

    configFileName = configFile.split('/')[-1]
    print(configFileName)
    configFile = get_hdfs_file(HDFS_BIN_PATH, configFileName, configFile, 1)
    print(configFile)

    config = readConfig(configFile)

    storageAccount = config[environment]['storageAccount']
    storageAccountKey = config[environment]['storageAccountKey']
    storageContainer = config[environment]['storageContainer']
    purgePeriodInYears = int(config[environment]['purgePeriodInYears'])
    tablesConfigHdfsFileLoc = config[environment]['tablesConfigHdfsFileLoc'].strip()
    azjars = config[environment]['azjars']
    num_mappers = config[environment]['numMappers']
    emailFrom = config[environment]['emailFrom']
    emailTo = config[environment]['emailTo']
    smtpServer = config[environment]['smtpServer']
    appName = config[environment]['appName']
    impala = config[environment]['impala']
    impalaSrvr = config[environment]['impalaSrvr']
    impalaPort = int(config[environment]['impalaPort'])
    impalaKerberos = config[environment]['impalaKerberos']
    impalaAuth = config[environment]['impalaAuth']
    impalaSSL = config[environment]['impalaSSL']
    print("tablesConfigHdfsFileLoc:" + tablesConfigHdfsFileLoc)
    try :
        (ret, out, err) = read_hdfs_file(HDFS_BIN_PATH, tablesConfigHdfsFileLoc)
        tables_list = createTableList(out)
        error_msg = ""
        isError = False
        for table in tables_list:
            try:
                conn = connect(host=impalaSrvr, port=impalaPort,
                               auth_mechanism=impalaAuth,
                               database=table['schema'],
                               kerberos_service_name=impalaKerberos, use_ssl=impalaSSL)
                backup_table_partitions(HDFS_BIN_PATH, HADOOP_BIN_PATH, table, purgePeriodInYears,
                                    storageAccount, storageAccountKey, storageContainer, num_mappers, azjars, conn
                                    )
                conn.close()
            except Exception as e:
                isError = True
                error = "exception occurred while working on table:[table=" + table['schema'] + "." + table['name'] + ", error=" + str(e) + "]"
                print(error)
                print(e)
                error_msg = error_msg + "\n" + error
                continue
        if isError:
            print("sent error email to:[emailTo=" + emailTo + "]")
            send_error_mail(error_msg, appName, emailTo, emailFrom, smtpServer)
    finally:
        print("end")
