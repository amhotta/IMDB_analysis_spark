#source $1

APPLICATION="aradretention-prod-incremental-copy"
APP_TMP="/tmp"
file_date=$(date '+%Y-%m-%d-%H-%M-%S')
APP_LOG = "/ez/data/wss/aradretention/incremental_copy/logs"

python arad_data_retention_incremental.py -c /ez/code/wss/aradretention/incremental_copy/incremental.config -e 'PROD' 1> ${APP_TMP}/${APPLICATION}-output-${file_date}.log 2>&1

if [ $? -eq 0 ]
then
  echo "Successfully executed incremental copy"
else
  echo "failed to execute incremental copy. For details please see latest log file in /ez/data/wss/aradretention/incremental_copy/logs"
fi

hdfs dfs -put  ${APP_TMP}/${APPLICATION}-output-${file_date}.log ${APP_LOG}
