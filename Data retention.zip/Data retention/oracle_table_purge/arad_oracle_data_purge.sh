#source $1
ENV=$1
APP_SCRIPT="aradretention_oralce_data_purge.py"
APP_CONFIG="/ez/code/wss/aradretention/config/oracledatapurge.config"
APPLICATION="aradretention-prod-oracledatapurge"
APP_TMP="/appsdata"
file_date=$(date '+%Y-%m-%d-%H-%M-%S')
APP_LOG="/ez/archive/wss/aradretention/oralce_data_purge/logs" #make sure this folder exists before running the script USER=aradretention
MAX_KINIT_TRY=5

iTry=0
until [ ${iTry} -ge ${MAX_KINIT_TRY} ]
do
        kinit -kt ${USER}.keytab ${USER}@DATASCIENCE.WEST.COM
        RC=$?
        if [[ ${RC} == 0 ]]
        then
                break;
        fi
        (( iTry++ ))

        sleep 15
done

if [[ ${iTry} -ge ${MAX_KINIT_TRY} ]]
then
        MESSAGE="Error: No of kinit attempts exceeded the max count <${MAX_KINIT_TRY}>, process FAILED."
        echo    "${MESSAGE}"  > ${APP_TMP}/${APPLICATION}-output-${file_date}.log
        hdfs dfs -put  ${APP_TMP}/${APPLICATION}-output-${file_date}.log ${APP_LOG}
        exit 1
fi

file_date=$(date '+%Y-%m-%d-%H-%M-%S')

spark2-submit --deploy-mode cluster --master yarn --conf spark.driver.maxResultSize=5g  --conf spark.yarn.dist.files=hive-site.xml --conf spark.shuffle.service.enabled=true  --conf spark.driver.memory=16G --conf spark.driver.cores=4 --executor-cores 4 --executor-memory 16G --conf spark.dynamicAllocation.minExecutors=2 --conf spark.dynamicAllocation.maxExecutors=4 --conf spark.dynamicAllocation.initialExecutors=2 --conf spark.dynamicAllocation.enabled=true --conf spark.executor.instances=2 --conf spark.sql.shuffle.partitions=40 --conf spark.yarn.maxAppAttempts=1 --queue root.ss --conf spark.yarn.appMasterEnv.PYSPARK_DRIVER_PYTHON=/usr/local/bin/python --conf spark.yarn.appMasterEnv.PYSPARK_PYTHON=/usr/local/bin/python ${APP_SCRIPT} -c ${APP_CONFIG} -e ${ENV} 1> ${APP_TMP}/${APPLICATION}-output-${file_date}.log 2>&1

hdfs dfs -put  ${APP_TMP}/${APPLICATION}-output-${file_date}.log ${APP_LOG}



