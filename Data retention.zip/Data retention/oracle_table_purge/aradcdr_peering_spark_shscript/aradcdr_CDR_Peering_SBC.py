################################################################################
#
# File: aradcdr_sbc4500.py
#
# Description:Utility for loading data for CDR.
#
#
# Script Modification Record
#
# Date            Name         Description
# --------------------------------------------------------------------
# NOV-15-2019	   YB		Initial Creation
################################################################################
from pyspark import SparkContext, SparkConf
from pyspark.sql.functions import broadcast
from pyspark.sql.types import StringType, StructType, StructField
from pyspark.sql import HiveContext
from datetime import datetime
from os import listdir
from os.path import isfile, join
import sys, os
import subprocess
import ConfigParser
from pyspark.sql import Row
from pyspark import StorageLevel
import smtplib, traceback
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import shlex
import commands
import re
from impala.dbapi import connect
from datetime import datetime
from datetime import timedelta
from pyspark.sql.functions import concat, split, lit, from_unixtime, unix_timestamp
from pyspark.sql import functions as sf

# Global Variable
ARAD_DICT = {}
metric_col = []


# Get HDFS File
def getHDFSFile(fileName, checker):
    localFile = os.path.basename(fileName)
    if os.path.isfile(localFile):
        print(localFile + " already exists. Ignore HDFS get")
    else:
        try:
            rc = commands.getstatusoutput("hdfs dfs -get " + fileName  )
            # commands.getstatusoutput => for  running the system command this returns a tuple as (status, output),
            # \ output can also be a error message
        except Exception as e:
            print "Printing Exception1 below:"
            print e
            pass
    if checker and not os.path.isfile(localFile):
        print "HDFS Get failed to download config file. Exiting..."
        sys.exit(-1)
    return localFile


# Initializes the spark context
def initSparkContext(user):
    con = 'kinit -kt {0} {1}@DATASCIENCE.WEST.COM'.format(ARAD_DICT['keytabFile'], ARAD_DICT['user'])
    (rc, out) = run_cmd(con)
    if rc != 0:
        print "Error: KINIT not successful:" + out
        sys.exit(-1)

    pyconf = SparkConf().setAppName("Spark Check").set("spark.sql.shuffle.partitions", "50")
    sc = SparkContext(conf=pyconf)
    return sc


# Check Arguments
def checkArguments():
    if len(sys.argv) != 4:
        print "Need config file and application name to proceed. Exiting..."
        sys.exit(-1)
    else:
        print "Arguments defined. Process starting..."


# Initialize Global Variables
def defineGlobals():
    try:
        ARAD_DICT['user'] = getConfig(configParser, server, 'USER')
        ARAD_DICT['keytab'] = getConfig(configParser, server, 'KEYTAB')
        ARAD_DICT['keytabFile'] = getHDFSFile(ARAD_DICT['keytab'], 0)
        ARAD_DICT['impala'] = getConfig(configParser, server, 'IMPALA')
        ARAD_DICT['appMetrics'] = getConfig(configParser, server, 'APP_METRICS')
        ARAD_DICT['appDataMetrics'] = getConfig(configParser, server, 'APP_DATA_METRICS')
        ARAD_DICT['dbStg'] = getConfig(configParser, server, 'DB_STG')
        ARAD_DICT['dbRep'] = getConfig(configParser, server, 'DB_REP')
        ARAD_DICT['receiver'] = getConfig(configParser, server, 'RECEIVER')
        ARAD_DICT['appTmp'] = getConfig(configParser, server, 'APP_TMP_FILE')
        ARAD_DICT['impalarefresh'] = getConfig(configParser, server, 'IMPALAREFRESH')
        ARAD_DICT['impalaSvr'] = getConfig(configParser, server, 'IMPALASVR')
        ARAD_DICT['impalaPort'] = getConfig(configParser, server, 'IMPALAPORT')
        ARAD_DICT['impalaKerberos'] = getConfig(configParser, server, 'IMPALAKERBEROS')
        ARAD_DICT['authenticate'] = getConfig(configParser, server, 'AUTHENTICATE')
        ARAD_DICT['ssl'] = getConfig(configParser, server, 'SSL')
        ARAD_DICT['location'] = getConfig(configParser, server, 'LOCATION')

        ARAD_DICT["sender"] = getConfig(configParser, server, 'SENDER')
        ARAD_DICT['recipient'] = getConfig(configParser, server, 'RECIPIENT')
        ARAD_DICT['smtpServer'] = getConfig(configParser, server, 'SMTPSERVER')
        ARAD_DICT['subjectPrefix'] = getConfig(configParser, server, 'SUBPREFIX')
        ARAD_DICT['incAssignGroup'] = getConfig(configParser, server, 'INCASSIGNGROUP')
        ARAD_DICT['incGenerator'] = getConfig(configParser, server, 'INCGENERATOR')
    except:
        print "Error: defineGlobals() not successful:" + traceback.format_exc()
        sys.exit(1)


def applicationCommonConfVar():
    ARAD_DICT['appIn'] = getConfig(configParser, application, 'APP_IN')
    ARAD_DICT['appArch'] = getConfig(configParser, application, 'APP_ARCH')
    ARAD_DICT['appWrk'] = getConfig(configParser, application, 'APP_WRK')
    ARAD_DICT['appStg'] = getConfig(configParser, application, 'APP_WRK_STG')
    ARAD_DICT['appStgTbl'] = getConfig(configParser, application, 'APP_STG')
    ARAD_DICT['iColRange'] = getConfig(configParser, application, 'ICOLRANGE')
    ARAD_DICT['grpKeyInd'] = getConfig(configParser, application, 'GROUP_KEY_INDEX')
    ARAD_DICT['grpKeyCol'] = getConfig(configParser, application, 'GROUP_KEY_COLUMN')
    ARAD_DICT['tsColInd'] = getConfig(configParser, application, 'TS_COL_INDEX')
    ARAD_DICT['tsCol'] = getConfig(configParser, application, 'TS_COL')
    ARAD_DICT['dataDir'] = getConfig(configParser, application, 'DATA_DIR')

    ARAD_DICT['inpFileStartPattern'] = getConfig(configParser, application, 'INPFILESTARTPATTERN')
    badRedWtrMrk = getConfig(configParser, application, 'BAD_REC_WATER_MARK')
    ARAD_DICT['badRcdWaterMark'] = int(badRedWtrMrk)
    ARAD_DICT['Part'] = getConfig(configParser, application, 'PART')
    ARAD_DICT['TimeZone'] = getConfig(configParser, application, 'TIMEZONE')


# Read config File
def readConfig(configFile):
    try:
        confParser = ConfigParser.RawConfigParser(allow_no_value=True)
        confParser.read(configFile)
        return confParser
    except:
        print "Error: readConfig() was not successful:" + traceback.format_exc()
        sys.exit(-1)


# Get the values for parameters from the config file
def getConfig(parser, section, option):
    try:
        return parser.get(section, option)
    except:
        print "Error: getConfig() was not successful:" + traceback.format_exc()
        sys.exit(-1)


# Format the error message and calls the function that sends the formatted error message
def format_err_msg(err_code, err_msg, flag="ERROR"):
    if flag == "ERROR":
        err = "ERROR: {0} Operation exited with errcode {1} \n".format(application, err_code)
        msg = "ERROR INFO: {0} \n".format(err_msg)
    else:
        err = "CDR-" + application + ": \n"
        msg = "-------------- \n {0}".format(err_msg)
    email_str = err + msg
    print email_str
    send_error_mail(email_str, flag)


# Function to send the error email.
def send_error_mail(errInfo, flag="ERROR"):
    SERVER = "smtp.west.com"
    BODY = errInfo
    SUBJECT = "{0}: Notification Email for {1} process".format(flag, application)
    msg = MIMEMultipart()
    msg['Subject'] = SUBJECT
    FROM = 'no-reply@den06had03.datascience.west.com'
    TO = ARAD_DICT['receiver'].split(',')
    msg.preamble = 'Multipart message.\n'
    try:
        print "EMAIL PROCESS STARTED"
        server = smtplib.SMTP(SERVER)
        if flag == "ERROR":
            msg.attach(MIMEText(BODY, 'plain'))
            server.sendmail(FROM, TO, msg.as_string())
            sys.exit(1)
        else:
            msg.attach(MIMEText(BODY, 'plain'))
            server.sendmail(FROM, TO, msg.as_string())
    except smtplib.SMTPException as e:
        print "Error: unable to send Error email with attachment", e
        sys.exit(1)


def print_info(message, debug_count):
    message_len = len(message)
    format_hypens = "-" * int(message_len / 2)
    db_message_len_hypens = "-" * len(message) * 2
    print(db_message_len_hypens)
    print("{0}{1}{0}".format(format_hypens, message))
    print(debug_count)
    print(db_message_len_hypens)

# Function to get the values to inserted into the metrics table and returns them as a dictionary.
def format_metric_row(APPNAME, rowcount, location, description, action, fnctName, jobNumber):

    format_dict = {
                    'JobNumber': jobNumber,
                    'FunctionName': fnctName,
                    'Application_name': APPNAME,
                    'Action': action,
                    'Description': description,
                    'Servername': 'na',
                    'Location': location,
                    'Recordcount': str(rowcount).strip(),
                    'Loadtimestamp': str(datetime.now())
                   }
    try:
        formatted_str = "{JobNumber}/##/{FunctionName}/##/{Application_name}/##/{Action}/##/{Description}/##/{Servername}/##/" \
                        "{Location}/##/{Recordcount}/##/{Loadtimestamp}".format(**format_dict)
        return formatted_str
    except:
        emsg = "Error: format_metric_row() was not successful: " + traceback.format_exc()
        eMail(1,emsg,"ERROR")



# Process command that have to be executed through command line
def run_cmd(hdfs_cmd):
    print 'Running system command: {0}'.format(hdfs_cmd)
    if len(hdfs_cmd.split("|")) > 1:
        return_code, res = commands.getstatusoutput(hdfs_cmd.split("|")[0])
    else:
        return_code, res = commands.getstatusoutput(hdfs_cmd)
    if return_code != 256 and len(hdfs_cmd.split("|")) > 1:
        return_code, res = commands.getstatusoutput(hdfs_cmd)
        return return_code, res

    return return_code, res


# Writes into the metrics table
def metric_insert():
    if len(metric_col) != 0:
            print ("METRIC INSERT")
            metric_rdd = pyContext.parallelize(metric_col, 1)
            metric_df,schemastr  = generate_dataframe(metric_rdd,True,"/##/")
            metric_df.registerTempTable("temptable")
            pysqlCon.sql("insert into table "+ARAD_DICT['dbRep'] +"."+ ARAD_DICT['appMetrics']+ " select * from temptable")
            impRefresh(ARAD_DICT['appMetrics'], "None", "None")
            print("Metrics Done")


# This functions takes rdd as the input and returns dataframe as output
def generate_dataframe(rdd_inp, schema_flg, deli, icolrange=[]):
    if schema_flg:
        field_count = rdd_inp.map(lambda s: len(s.split(deli))).take(1)
        print "FIELDCOUNT"
        print field_count
        print rdd_inp.take(1)
    else:
        field_count = icolrange
    map_to_tuple_RDD = rdd_inp.map(lambda s: tuple(s.split("/##/")))
    schemaString = ','.join(gen_dynamic_col_list("col", max(field_count), False))
    fields = [StructField(field_name, StringType(), True) for field_name in schemaString.split(",")]
    schema = StructType(fields)
    rdd_to_df = pysqlCon.createDataFrame(map_to_tuple_RDD, schema)
    return rdd_to_df, schemaString

def generate_dataframe_rdd(rdd_inp,schema_flg,deli,icolrange=[]):
    if schema_flg:
        print (schema_flg)
        field_count = rdd_inp.map(lambda s: len(s.split(deli))).take(1)
        print ("FIELDCOUNT")
        print (field_count)
        print ("True part")
    else:
        field_count = icolrange
        print (field_count)
    map_to_tuple_RDD = rdd_inp.map(lambda s: tuple(s.split(deli)))
    schemaString = ','.join(gen_dynamic_col_list("col",max(field_count), False))
    fields = [StructField(field_name, StringType(), True) for field_name in schemaString.split(",")]
    schema = StructType(fields)
    rdd_to_df = pysqlCon.createDataFrame(map_to_tuple_RDD,schema)
    return rdd_to_df,schemaString


# Function to generate columns and column names dynamically
def gen_dynamic_col_list(str, element, indx_flg):
    if indx_flg and type(1) == type(element):
        return ['{0}[{1}]'.format(str, x) for x in range(0, element)]
    elif indx_flg and type([]) == type(element):
        return ['{0}[{1}]'.format(str, x) for x in element]
    elif not indx_flg and type(1) == type(element):
        return ['{0}{1}'.format(str, x) for x in range(0, element)]
    else:
        return ['{0}{1}'.format(str, x) for x in element]


# This method will Add nulls to the valid lines which have less number of fields or columns
# def add_pipes(line, max_width):
#     reformatted_line = '{0}'.join(line.split('{0}')).format(str(ARAD_DICT['delimtr']))
#     if len(line.split(str(ARAD_DICT['delimtr']))) != max_width:
#         make_null = str(ARAD_DICT['delimtr']) * (max_width - len(line.split(str(ARAD_DICT['delimtr']))))
#         return reformatted_line + make_null
#     else:
#         return reformatted_line

def add_pipes(line, max_width):
    reformatted_line = ','.join(line.split(','))
    if len(line.split(',')) != max_width:
        make_null = ',' * (max_width - len(line.split(',')))
        return reformatted_line + make_null
    else:
        return reformatted_line

def incidentCreation(message):
    subject = ARAD_DICT['subjectPrefix'] + " Script: " + os.path.basename(sys.argv[0]) + ", Config File: " + sys.argv[1] + " & Environment: " + sys.argv[2]
    sender = "no-reply@datascience.west.com"
    message = "From: <" + sender + ">\nTo: <" +  ARAD_DICT['recipient'] + ">\nSubject: " + subject + "\n\n" + message

    try:
        toadd = ARAD_DICT['recipient'].split(',')
        smtpObj = smtplib.SMTP(ARAD_DICT['smtpServer'])
        smtpObj.sendmail(sender, toadd, message)
        logMessage("INFO - Successfully sent email alert")
        if len(sys.argv) == 5 and sys.argv[4].upper() == "YES":
            cmd = "./" + ARAD_DICT['incGenerator'] + " -g '" + ARAD_DICT['incAssignGroup'] + "' -e '" + ARAD_DICT['recipient'] + \
                    "' -s '" + subject + "' -d '" + subject + ". Check email for more details on errors' -V"
            rc = commands.getstatusoutput(cmd)
            if rc[0] == 0:
                logMessage("INFO - Successfully generated an incident")
            else:
                logMessage("ERROR - Unable to generate incident.\n" + rc[1])
    except:
        emsg =  traceback.format_exc()
        logMessage("ERROR -  Unable to send email because of :" + emsg)


def impRefresh(tbl,partName,partValue):
  try:
    conn = connect(host=ARAD_DICT['impalaSvr'], port=ARAD_DICT['impalaPort'],
                   auth_mechanism=ARAD_DICT['authenticate'],
                   kerberos_service_name=ARAD_DICT['impalaKerberos'],use_ssl=ARAD_DICT['ssl'])
    iCursor = conn.cursor()
    iCursor.execute("set max_row_size=8mb")
    if partName=="None":
        iCursor.execute("refresh "+ ARAD_DICT['dbRep']+"."+ tbl)
    else:
        iCursor.execute("refresh "+ ARAD_DICT['dbRep']+"."+ tbl)
        #iCursor.execute("compute incremental stats "+ ARAD_DICT['dbRep']+"."+ tbl+' PARTITION('+partName+'='+str(partValue)+')')
  except:
    # emsg = "Error: impRefresh() not successful." + traceback.format_exc()
    # eMail("1",emsg,"ERROR")
    emsg = "Error: Impala refresh for " +tbl+" table was not successful. "+ traceback.format_exc()
    eMail("1",emsg,"ERROR")


def partitioncheck(purgeDate):
    checkPart = purgeDate[:10].replace('-', '')
    print_info("checking if old Partition Exits: "+checkPart, "None")
    hdfs_chk_done = "hdfs dfs -test -e " + ARAD_DICT['dataDir'] + "/" + ARAD_DICT['stgTbl'] + "/" + ARAD_DICT[
        'PartName'] + "=" + checkPart
    (ret_cde, out) = run_cmd(hdfs_chk_done)
    print("RETURNCODE")
    print(ret_cde)
    if ret_cde == 0:
        print_info("Removing Partition : " + checkPart, "None")
        sqlQuery = "alter table " + ARAD_DICT['dbRep'] + "." + ARAD_DICT['stgTbl'] + " drop partition(" + ARAD_DICT[
            'PartName'] + "=" + checkPart + ")"
        print 'Alter table query :' + sqlQuery
        pysqlCon.sql(sqlQuery)
        print_info("Removing Partition directory: " + checkPart, "None")
        hdfs_rm_part = "hdfs dfs -rm -r "+ ARAD_DICT['dataDir'] + "/" + ARAD_DICT['stgTbl'] + "/" + ARAD_DICT['PartName'] + "=" + checkPart
        (rt, res) = run_cmd(hdfs_rm_part)
        metric_col.append(
            format_metric_row(application, "na", "na", "Removing data that exceeded Retention Period",
                              "Removing data that exceeded Retention Period" + checkPart, "partitioncheck", jobNumber))
    else:
        print_info("No Partition : " + checkPart, "None")
        metric_col.append(
            format_metric_row(application, "na", "na", "No data that exceeded Retention Period",
                              "No data exceeded Retention Period" + checkPart, "partitioncheck", jobNumber))

def spark_rdd_stage():
  try:
    print_info("SPARK STAGE 1 - RDD Operations on Input Dataset", "")
    icolrange = map(int,ARAD_DICT['iColRange'].split(","))
    print_info("Valid Row width lengths are ", icolrange)

    # Creates RDD for the input and filters out all the blank lines from the file
    inpRdd = pyContext.textFile(ARAD_DICT['appStg'] + "/" + ARAD_DICT['inpFileStartPattern']+"*").filter(lambda x: len(x) > 0).cache()

    # Total rows in the dataset 
    totalRowCount = inpRdd.count()
    metric_col.append(format_metric_row(application, totalRowCount, "na", "Total Row Counts", "TOTAL ROW COUNT", "spark_rdd_stage",jobNumber))
    print_info("STAGE-1 - GET TOTAL NUMBER OF ROWS FROM INPUT", totalRowCount)
    distinctRdd = inpRdd.distinct()
    distinctCount = distinctRdd.count() 
    print_info("STAGE-2 - GET TOTAL NUMBER OF DISTINCT ROWS FROM INPUT", distinctCount)
    dupCount = totalRowCount - distinctCount
    print_info("STAGE-3 - TOTAL NUMBER OF DUPLICATE ROWS IN INPUT", dupCount)
    if dupCount > 0:metric_col.append(format_metric_row(application, dupCount, "na", "Duplicates found in data set", "DUPLICATES", "spark_rdd_stage",jobNumber))
    # Skips the invalid rows that do not match with the width of the rows provided as icolrange in
    #  the config In addition, it also filters out the empty piped row
    
    #check for valid rows(regex - To process if the data has comma inside double quotes within row data)
    prefinal_rdd = distinctRdd.map(lambda z: z.replace(",", "-,-"))
    
    preValid_rows = prefinal_rdd.filter(lambda x: (len(re.findall(r"(\".*?\"-|[^\",\s]+)(?=\s*,|\s*$)",x)) in icolrange))
    valid_rows = preValid_rows.map(lambda z: z.replace("-,-", ","))
    # Get the count of total valid rows from the input.
    valid_row_count = valid_rows.count()
    print_info("STAGE-4 - FILTER VALID ROWS ", str(valid_row_count))
    preInValid_rows = prefinal_rdd.filter(lambda x: (len(re.findall(r"(\".*?\"-|[^\",\s]+)(?=\s*,|\s*$)",x)) not in icolrange))
    inValid_rows = preInValid_rows.map(lambda z: z.replace("-,-", ","))
    inValid_row_count = inValid_rows.count()
    print_info("STAGE-4 - FILTER INVALID ROWS ", str(inValid_row_count))

    # Filters the empty rows.
    empty_rows = distinctRdd.filter(lambda x: x.split(ARAD_DICT['delimtr']).count('') == len(x.split(ARAD_DICT['delimtr'])))

    # Counts the empty rows in the invalid_rows rdd
    emp_row_cnt = empty_rows.count()

    print_info("STAGE-5 - GET COUNT OF EMPTY ROWS", str(emp_row_cnt))

    # Checks if there any empty rows and records them to the metric log list
    if emp_row_cnt != 0:
        metric_col.append(format_metric_row(application,emp_row_cnt, "na", "Empty Row Counts", "Filter empty rows", "spark_rdd_stage",jobNumber))

    non_empty_invalid_cnt = prefinal_rdd.filter(lambda x: (len(re.findall(r"(\".*?\"-|[^\",\s]+)(?=\s*,|\s*$)",x)) not in icolrange))

    non_empty_row_cnt = non_empty_invalid_cnt.count()

    print_info("STAGE-6 - GET COUNT OF NON EMPTY INVALID ROWS",str(non_empty_row_cnt))
    distinctRdd.unpersist() 
    # Map the lines to match with the target schema
    # Adds empty pipes to the rows that has valid row width but less than max row width which is defined in the icolrange.
    old_to_new_RDD = valid_rows.map(lambda y: add_pipes(y, max(icolrange)))
    
    # Get primary keys and the partition time column.
    group_key_indx = map(int,ARAD_DICT['grpKeyInd'].split(","))
    ord_col = int(ARAD_DICT['tsColInd'])
    join_cols = ARAD_DICT['grpKeyCol'].split(",")

    print_info("group key indexes are", group_key_indx)
    print_info("ORDERING COLUMN", ord_col)
    print_info("DATABASE TO FETCH", ARAD_DICT['dbRep'])
    print_info("TABLE TO FETCH", ARAD_DICT['repTbl'])
    print_info("TIMESTAMP COLUMN TO FILTER", ARAD_DICT['tsCol'])
    print_info("Joining columns are ", join_cols)

    # Dynamically Generates column indexes
    grouping_cols = ",".join(gen_dynamic_col_list("col", group_key_indx, False))

    # Converts RDD object to Dataframe object
    rdd_to_DF,schemaString = generate_dataframe_rdd(old_to_new_RDD,False,ARAD_DICT['delimtr'],icolrange)
    # Insert the clean rows into the staging table.
    old_to_new_RDD.saveAsTextFile(ARAD_DICT['appStgTbl'])
    vwQry= "select hive_tbl.* from {0}.{1} as hive_tbl".format(ARAD_DICT['dbStg'], ARAD_DICT['stgVw'])

    schem=schemaString.split(',')
    clean_rows = pysqlCon.sql(vwQry).toDF(*schem)
    get_partition_list = "select distinct cast(date_format({0},'{3}') as int) as part_val from {1}.{2}".format(ARAD_DICT['tsCol'],ARAD_DICT['dbStg'], ARAD_DICT['stgVw'],ARAD_DICT['Part'])
    query_partition = pysqlCon.sql(get_partition_list)
    query_partition.registerTempTable("part_info")
    query_str = "select hive_tbl.* from {0}.{1} as hive_tbl join part_info part on hive_tbl.daily_part= part.part_val".format(ARAD_DICT['dbRep'], ARAD_DICT['repTbl'])
    pysqlCon.sql("set hive.auto.convert.join=true")
    print("Execute Query String", query_str)
    curPartDf = pysqlCon.sql(query_str)
    dyn_join_cond = "&".join(["(curPartDf.{0}".format(join_cols[x]) + " == clean_rows.col{0})".format(group_key_indx[x]) for x in range(0, len(join_cols))])
    # Generate dynamic join conditions based the joins columns, input data column indexes provided in the config.
    unChangedDf = curPartDf.join(clean_rows, eval(dyn_join_cond), "left_anti")
    updCount = curPartDf.count() - unChangedDf.count()
    insCount = clean_rows.count() - updCount
    metric_col.append(format_metric_row(application, updCount, "na", "Count of rows updated", "UPDATED ROW COUNT", "spark_rdd_stage",jobNumber))
    metric_col.append(format_metric_row(application, insCount, "na", "Count of rows inserted", "INSERTED ROW COUNT", "spark_rdd_stage",jobNumber))
    valDf=unChangedDf.drop("daily_part")
    # drop daily_part and etl_ts field before union
    valDf=valDf.drop("data_timestamp")
    toBeInsDF = valDf.union(clean_rows)
    toBeInsDF.registerTempTable("appendTable")
    pysqlCon.sql("set hive.exec.dynamic.partition=true")
    pysqlCon.sql("set hive.exec.dynamic.partition.mode=nonstrict")
    pysqlCon.sql("set parquet.compression=snappy")
    insertQry = "insert overwrite table {0}.{1} partition(daily_part) select *,to_utc_timestamp(current_timestamp(),'EST5EDT'),cast(date_format({2},'{3}') as int) as part_val from appendTable".format(ARAD_DICT['dbRep'], ARAD_DICT['repTbl'],ARAD_DICT['tsCol'] , ARAD_DICT['Part'])
    print insertQry
    pysqlCon.sql(insertQry)
    table_name=pysqlCon.table(ARAD_DICT['dbRep'] + "." + ARAD_DICT['repTbl'])
    tblCnt=table_name.count()
    metric_col.append(format_metric_row(application, tblCnt, "na", "Total No of records in the table", "TABLE COUNT", "spark_rdd_stage",jobNumber))
    # If Bad records are present save them to a file.
    if not inValid_rows.isEmpty():
        metric_col.append(format_metric_row(application, inValid_row_count, ARAD_DICT['appWrk'] + "/BadRecords" + CURRENT_DATE_TIME, "Column count does not match.","BAD RECORDS", "spark_rdd_stage",jobNumber))
        print(inValid_rows)
        inValid_row_count.saveAsTextFile(ARAD_DICT['appWrk'] + "/BadRecords" + CURRENT_DATE_TIME)
        errmsg = "Error: Bad Records found in Incoming Data: " + traceback.format_exc()
        incidentCreation(errmsg)
        if non_empty_row_cnt >= ARAD_DICT['badRcdWaterMark']:
           badChckFl = "hdfs  dfs -touchz " +  ARAD_DICT['appWrk']+ "/" + application + "_BADCHCKFL.txt "
           print badChckFl
           (rc1, out) = run_cmd(badChckFl)
           if rc1 != 0:
                print badChckFl + " command not successful. Cannot move on with proccessing." + out 
                emsg = badChckFl + " command not successful." + out
                eMail(1,emsg,"ERROR")
    # Insert Completion of process into the metrics table
    metric_col.append(format_metric_row(application, "na", "na", "Process Completed", "COMPLETED", "spark_rdd_stage",jobNumber))
  except:
    emsg = "Error: spark_rdd_stage() was not successful: " + traceback.format_exc()
    eMail(1,emsg,"ERROR")
  try:
    if len(metric_col) != 0:
       exec_metric = metric_insert()
  except:
    metric_rdd = pyContext.parallelize(metric_col, 1)
    metric_rdd.saveAsTextFile(ARAD_DICT['appWrk'] + "/Metricdetails" + CURRENT_DATE_TIME)
    err_msg = "The process failed when writing into metrics tables. The metrics details are available at " + ARAD_DICT['appWrk'] + "/Metricdetails" + CURRENT_DATE_TIME + traceback.format_exc()
    eMail("1",err_msg,"INFO")


def cdr():
    # Get configuration details specific to CDR.
    applicationCommonConfVar()
    ARAD_DICT['repTbl'] = getConfig(configParser, application, 'REP_TBL')
    ARAD_DICT['stgTbl'] = getConfig(configParser, application, 'STG_TBL')
    ARAD_DICT['stgVw'] = getConfig(configParser, application, 'STG_VW')
    ARAD_DICT['delimtr'] = getConfig(configParser, application, 'DELIMIT')
    ARAD_DICT['retentionPeriod'] = getConfig(configParser, application, 'RETENTION_PERIOD')
    ARAD_DICT['PartName'] = getConfig(configParser, application, 'PART_NAME')

    # Get the list of filenames being processed
    inpFileNames = "hdfs dfs -stat '%n' " + ARAD_DICT['appStg'] + "/*  2>/dev/null"

    (rc1, out) = run_cmd(inpFileNames)
    if rc1 == 0:
        # Upload the status STARTED and the input file names in metrics table.
        file_list = out.split("\n")
        if len(file_list) > 0:
           flList = '|'.join([str(i) for i in file_list])
           metric_col.append(format_metric_row(application, "na", "na", "Process started", "STARTED", "cdr()", jobNumber))
           metric_col.append(format_metric_row(application, flList, "na", "List of files being processed and the count.","List of files being processed and the count","spark_rdd_stage", jobNumber))
           # Truncate the staging table by removing the staging table directory. 
           hdfsRm = "hdfs dfs -rm -r " + ARAD_DICT['appStgTbl']  
           (rc, out) = run_cmd(hdfsRm)
           if rc != 0:
              emsg= hdfsRm + " command not successful. Cannot move on with proccessing." + out
              eMail(1,emsg,"WARN")
           # Call the sparkrddstage function to process the input files.
           spark_rdd_stage()
    else:
        emsg = inpFileNames + " command not successful. Cannot move on with proccessing." + out
        eMail(1, emsg, "ERROR")


if __name__ == "__main__":
    CURRENT_DATE_TIME = str(datetime.now())
    CURRENT_DATE_TIME = CURRENT_DATE_TIME.replace(" ", "-").replace(":", "-").split(".")[0]

    print "step1:" + (str(CURRENT_DATE_TIME))
    try:
        eMail = format_err_msg
        checkArguments()
        # Get the input arguments and read the config file.
        aradConfig = sys.argv[1]
        application = sys.argv[2]
        server = sys.argv[3]
        ARAD_DICT['configFile'] = getHDFSFile(aradConfig, 1)
        configParser = readConfig(ARAD_DICT['configFile'])
        print "configfile"
        print ARAD_DICT['configFile']
        defineGlobals()
        pyContext = initSparkContext(ARAD_DICT['user'])
        jobNumber = pyContext.applicationId
        pysqlCon = HiveContext(pyContext)
        cdr()

    finally:
        if 'configFile' in ARAD_DICT and os.path.isfile(ARAD_DICT['configFile']):
            os.remove(ARAD_DICT['configFile'])
        if 'keytabFile' in ARAD_DICT and os.path.isfile(ARAD_DICT['keytabFile']):
            os.remove(ARAD_DICT['keytabFile'])



