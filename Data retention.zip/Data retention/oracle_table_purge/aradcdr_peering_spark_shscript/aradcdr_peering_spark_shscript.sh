#!/bin/bash
################################################################################
#
# File: aradtcc_spark_shscript.sh
#
# Description: Call Spark2-Submit command and capture the error.
#
# Script Modification Record
#
# Date            Name         Description
# --------------------------------------------------------------------
#
# 13-may-2020    PK Team      Spark-submit job
# 13-may-2020    PK Team      Insert into metric table if job fails
################################################################################

source $1

file_date=$(date '+%Y-%m-%d-%H-%M-%S')

spark2-submit --deploy-mode cluster --master yarn --conf spark.driver.maxResultSize=5g  --conf spark.yarn.dist.files=hive-site.xml --conf spark.shuffle.service.enabled=true  --conf spark.driver.memory=16G --conf spark.driver.cores=4 --executor-cores 4 --executor-memory 16G --conf spark.dynamicAllocation.minExecutors=2 --conf spark.dynamicAllocation.maxExecutors=4 --conf spark.dynamicAllocation.initialExecutors=2 --conf spark.dynamicAllocation.enabled=true --conf spark.executor.instances=2 --conf spark.sql.shuffle.partitions=40 --conf spark.yarn.maxAppAttempts=1 --queue ss --conf spark.yarn.appMasterEnv.PYSPARK_DRIVER_PYTHON=/usr/local/bin/python --conf spark.yarn.appMasterEnv.PYSPARK_PYTHON=/usr/local/bin/python ${PROCESS} ${CONFIG} ${APPLICATION} ${HOST} 1> ${APP_TMP}/${APPLICATION}-output-${file_date}.log 2>&1

hdfs dfs -put  ${APP_TMP}/${APPLICATION}-output-${file_date}.log ${APP_LOG} 

status=`cat ${APP_TMP}/${APPLICATION}-output-${file_date}.log | grep -i "final status:" | tail -1`
echo "MY STATUS <${status}>" 


if [[  ${status} != "" && ${status} == *"SUCCEEDED"* ]]
then
    echo "SUCCEEDED"
    echo $(date '+%Y-%m-%d-%H-%M-%S')
else
    beeline -u ${HIVE}  -e "insert into ${DB_REP}.${METRICS_TBL} select '${APPLICATION}','${APPLICATION}','FAILED','na','na','na',current_timestamp()" --silent=true
    beeline -u ${IMPALA} -e "refresh ${DB_REP}.${METRICS_TBL}" --silent=true

    RC=$?
    if [[ ${RC} != 0 ]]
    then
          MESSAGE="Insert into metrics status 'FAILED' failed."
          echo    "${MESSAGE}"  >> ${APP_TMP}/${APPLICATION}-output-${file_date}.log
          #hdfs dfs -put  ${APP_TMP}/${APPLICATION}-output-${file_date}.log ${APP_LOG} 
          echo ${MESSAGE}
          exit 1
                    
    fi
fi
exit 0