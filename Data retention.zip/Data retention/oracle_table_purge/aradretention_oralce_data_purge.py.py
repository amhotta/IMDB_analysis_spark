import argparse
import subprocess
import sys
from datetime import date, timedelta
import datetime
import base64
import requests
import logging
import os
import configparser
import time
import smtplib, traceback
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pyspark import SparkContext, SparkConf
from pyspark import SQLContext
import commands
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql.functions import to_date
from pyspark.sql.functions import year,month
from pyspark.sql.functions import concat
from pyspark.sql.functions import format_string
#import urllib.parse
from pyspark.sql.functions import unix_timestamp, from_unixtime
from pyspark.sql.functions  import date_format

#spark2-submit --jars /opt/cloudera/parcels/CDH/jars/hadoop-azure-2.6.0-cdh5.16.2.jar,/opt/cloudera/parcels/CDH/jars/microsoft-windowsazure-storage-sdk-0.6.0.jar --numMappers=1 --deploy-mode client --executor-memory 5g --num-executors 5 /home/psuman/mlProjects/databox_validation/main.py
#./bin/spark-submit --jars /opt/cloudera/parcels/CDH/jars/hadoop-azure-2.6.0-cdh5.16.2.jar,/opt/cloudera/parcels/CDH/jars/microsoft-windowsazure-storage-sdk-0.6.0.jar --numMappers=1 --master yarn --deploy-mode cluster --executor-memory 512m --num-executors 5 /home/psuman/mlProjects/databox_validation/main.py -a /home/psuman/mlProjects/databox_validation/app.conf -t /home/psuman/mlProjects/databox_validation/tables.conf -e PROD

globals = {}

def run_cmd(args_list):
    print('Running system command: {0}'.format(' '.join(args_list)))
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    s_output, s_err = proc.communicate()
    s_return = proc.returncode
    return s_return, s_output, s_err

def read_hdfs_file(HDFS_BIN_PATH, hdfs_location) :
    (ret, out, err)= run_cmd([HDFS_BIN_PATH, 'dfs', '-cat', hdfs_location])
    print(ret)
    if ret == 0:
        return (ret, out, err)
    else:
        print("There is an error during config file read:" + err.strip().decode("utf-8"))
        sys.exit(-1)

def createTableList(out):
    lines = out.decode("utf-8").split('\n')
    tablesList = []
    for line in lines:
        splits = line.strip().split(",")
        if len(splits) > 1:
            tableConf = {}
            #schemaTable = splits[0]
            #print(schemaTable)
            #print(schemaTable.split(","))
            tableConf['schema'] = splits[0]
            tableConf['name'] = splits[1]
            tableConf['timestampCol'] = splits[2]
            tableConf['format'] = splits[3]
            tableConf['hdfs_location'] = splits[4]
            tablesList.append(tableConf)
    return  tablesList

# Process command that have to be executed through command line
def run_kinit_cmd(hdfs_cmd):
    print('Running system command: {0}'.format(hdfs_cmd))
    if len(hdfs_cmd.split("|")) > 1:
        return_code, res = commands.getstatusoutput(hdfs_cmd.split("|")[0])
    else:
        return_code, res = commands.getstatusoutput(hdfs_cmd)
    if return_code != 256 and len(hdfs_cmd.split("|")) > 1:
        return_code, res = commands.getstatusoutput(hdfs_cmd)
        return return_code, res

    return return_code, res

def send_error_mail(errInfo, application, emailTo, emailFrom, smtpServer, flag="ERROR"):
    BODY = errInfo
    SUBJECT = "{0}: Notification Email for {1} process".format(flag, application)
    msg = MIMEMultipart()
    msg['Subject'] = SUBJECT
    TO = emailTo.split(',')
    msg.preamble = 'Multipart message.\n'
    try:
        print("EMAIL PROCESS STARTED")
        server = smtplib.SMTP(smtpServer)
        msg.attach(MIMEText(BODY, 'plain'))
        server.sendmail(emailFrom, TO, msg.as_string())
    except smtplib.SMTPException as e:
        print("Error: unable to send Error email with attachment", e)
        sys.exit(1)

def run_kinit_cmd(kinit_cmd):
    print 'Running system command: {0}'.format(kinit_cmd)
    if len(kinit_cmd.split("|")) > 1:
        return_code, res = commands.getstatusoutput(kinit_cmd.split("|")[0])
    else:
        return_code, res = commands.getstatusoutput(kinit_cmd)
    if return_code != 256 and len(kinit_cmd.split("|")) > 1:
        return_code, res = commands.getstatusoutput(kinit_cmd)
        return return_code, res

    return return_code, res

def get_hdfs_file(HDFS_BIN_PATH, fileName, hdfs_location, checker):
    localFile = os.path.basename(fileName)

    if os.path.isfile(fileName):
        print(fileName + " already exists. removing file.")
        os.remove(localFile)

    try:
        (ret, out, err) = run_cmd([HDFS_BIN_PATH, 'dfs', '-get', hdfs_location])
    except Exception as e:
        print("Printing Exception1 below:")
        print(e)
        pass

    if checker and not os.path.isfile(localFile):
        print("HDFS Get failed to download config file. Exiting...")
        sys.exit(-1)
    return localFile

def readConfig(configFile):
    try:
        confParser = configparser.RawConfigParser(allow_no_value=True)
        confParser.read(configFile)
        return confParser
    except Exception as e:
        error = "Error: readConfig() was not successful:[configFile=" + configFile + "]"
        if 'errors' in globals:
            globals['errors'] = globals['errors'] + "\n" + error
        else:
            globals['errors'] = error
        globals['isError'] = True
        print(error)
        print(e)
        sys.exit(-1)

def delete_hdfs_folder(HDFS_BIN_PATH, hdfsPath):
    (ret, out, err) = run_cmd([HDFS_BIN_PATH, 'dfs', '-rmr', hdfsPath])
    if ret == 0:
        print("successfully deleted hdfs folder :" + hdfsPath)
    else:
        print("error while deleting hdfs folder:[hdfsPath="+hdfsPath + ", error=" + err.decode("utf-8") + "]")
        


def backup_to_adls(HADOOP_BIN_PATH, hadoop_path, schemaName, tableName, storageAccountKey, storageAccount, containerName, num_mappers, azjars):
       
    
    azurePath = "wasb://" + containerName + "@" + storageAccount + "/" + schemaName + "/" + table['name']
    
    
    #azureFileUrl = "wasb://" + storageContainer + "@" + storageAccount + "/" + table['schema'] + "/" + table['name'] + "/" + "*.parquet"
    
    startTime = time.time()
    print("backing up table to adls started [table=" + tableName + ", schemaName=" + schemaName + ", hdfsPath=" + hadoop_path + ",azurePath=" + azurePath + "]")

    (ret, out, err) = run_cmd(
            [HADOOP_BIN_PATH, 'distcp', '-Dfs.AbstractFileSystem.wasb.Impl=org.apache.hadoop.fs.azure.Wasb',
             '-Dfs.azure.account.key.' + storageAccount + '=' + storageAccountKey, '-libjars',
             azjars, '-m', num_mappers, hadoop_path, azurePath])
    endTime = time.time()
    if ret == 0:
        print("backing up partition to adls completed successfully [table=" + tableName + ", hdfsPath=" + hadoop_path + ",azurePath=" + azurePath +
              ",timeTookInSecs=" + str((endTime-startTime)) + "]")
         
        
    else:
        print("error while copying using distcp [table=" + tableName + ", hdfsPath=" + hadoop_path + ",azurePath=" + azurePath + ", error=" + err.decode("utf-8") + "]")
        
        
        

if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    # Required Arguments
    parser.add_argument('-c', '--config-file', dest='configFile', help='config file location', nargs='+')
    parser.add_argument('-e', '--envrionment', dest='environment', help='environment', nargs='+')

    results = parser.parse_args()

    if results.configFile is None or results.environment is None:
        parser.print_help()
        sys.exit(-1)

    configFile = results.configFile[0]
    environment = results.environment[0]
    if environment != 'PREPROD' and environment != 'PROD':
        print("unknown environment")
        sys.exit(-1)

    print("script running in :" + environment + " environment")

    HADOOP_BIN_PATH = '/usr/bin/hadoop'
    HDFS_BIN_PATH = '/usr/bin/hdfs'

    configFileName = configFile.split('/')[-1]
    configFile = get_hdfs_file(HDFS_BIN_PATH, configFileName, configFile, 1)

    config = readConfig(configFile)

    storageAccount = config[environment]['storageAccount']
    storageAccountKey = config[environment]['storageAccountKey']
    storageAccountName = config[environment]['storageAccountName']
    storageContainer = config[environment]['storageContainer']
    targetstorageContainer = config[environment]['targetstorageContainer']
    purgePeriodInYears = int(config[environment]['purgePeriodInYears'])
    azureApiversion = config[environment]['azureApiversion']
    tablesConfigHdfsFileLoc = config[environment]['tablesConfigHdfsFileLoc'].strip()
    azjars = config[environment]['azjars']
    num_mappers = config[environment]['numMappers']
    emailFrom = config[environment]['emailFrom']
    emailTo = config[environment]['emailTo']
    smtpServer = config[environment]['smtpServer']
    appName = config[environment]['appName']
    impala = config[environment]['impala']
    impalaSrvr = config[environment]['impalaSrvr']
    impalaPort = int(config[environment]['impalaPort'])
    impalaKerberos = config[environment]['impalaKerberos']
    impalaAuth = config[environment]['impalaAuth']
    impalaSSL = config[environment]['impalaSSL']
    kinitUser = config[environment]['kinitUser']
    keyTab = config[environment]['keyTab']
    

    try:
        con = 'kinit -kt {0} {1}@DATASCIENCE.WEST.COM'.format(keyTab, kinitUser)
        (rc, out) = run_kinit_cmd(con)
        if rc != 0:
            #error = "Error: KINIT not successful:" + out
            print("Error: KINIT not successful")
            #send_error_mail(error, appName, emailTo, emailFrom, smtpServer)
            sys.exit(-1)
        (ret, out, err) = read_hdfs_file(HDFS_BIN_PATH, tablesConfigHdfsFileLoc)
        tables_list = createTableList(out)
        error_msg = ""
        isError = False
        storageAccountAuth = "fs.azure.account.key." + storageAccount

        spark = SparkSession \
            .builder \
            .appName("oracle_data_purge") \
            .getOrCreate()

        spark.conf.set(storageAccountAuth, storageAccountKey)

        for table in tables_list:
            try:
                azureFileUrl = "wasb://" + storageContainer + "@" + storageAccount + "/" + table['schema'] + "/" + table['name'] + "/" + "*.parquet"
                
                #azuretargetFileUrl= "wasb://" + "orccontainer" + "@" + storageAccount + "/" + table['schema'] + "/" + table['name']
                azureDf = spark.read.parquet(azureFileUrl)
                azureDfCount = azureDf.count()
                print("****** Count ********:" + str(azureDfCount))
                
                
                
                print("***Source Dataframe****:"+ str(azureDf.head(5)))
                azureDf.write.mode("overwrite").format("parquet").save(table['hdfs_location'])
                #azureDf1 = azureDf.withColumn(table['timestampCol'],from_unixtime(unix_timestamp(table['timestampCol'], table['format'])))
                from pyspark.sql import types
                from pyspark.sql import functions as F
                

                azureDf1 = azureDf.withColumn(table['timestampCol'], F.from_unixtime(F.col(table['timestampCol'])/1000, table['format']))
                df_with_year_and_month5 = (azureDf1.withColumn("monthly_part", date_format(col(table['timestampCol']), "yyyyMM")))

                #df_with_year_and_month5 = azureDf1.withColumn("monthly_part",concat(year(to_date(col(table['timestampCol']), table['format'])) , format_string("%02d", month(to_date(col(table['timestampCol']), table['format'])))))
                print("Dataframe Target:"+ str(df_with_year_and_month5.head(10)))
                
                df_with_year_and_month5.write.partitionBy("monthly_part").mode("overwrite").format("parquet").save(table['hdfs_location'])
                
                hdfsPath = table['hdfs_location']
                backup_to_adls(HADOOP_BIN_PATH, hdfsPath, table['schema'], table['name'], storageAccountKey, storageAccount, targetstorageContainer, num_mappers, azjars)
                
                tgtazurePath = "wasb://" + targetstorageContainer + "@" + storageAccount + "/" + table['schema'] + "/" + table['name']
                tgtazureDf=spark.read.parquet(tgtazurePath)
                tgtazureDfCount=tgtazureDf.count()
                
                if azureDfCount == tgtazureDfCount:
                    print("VALIDATION SUCCESS [schemaName=:"+ table['schema'] + ",tableName=" + table['name'] + ",sourcePath=" + azureFileUrl +                     ",targetPath =" + tgtazurePath + ",sourceCount=" + str(azureDfCount) + ", targetCount=" + str(tgtazureDfCount) + "]")
                else:
                    print("VALIDATION FAILED [schemaName=:"+ table['schema'] + ",tableName=" + table['name'] + ",sourcePath=" + azureFileUrl +                     ",targetPath =" + tgtazurePath + ",sourceCount=" + str(azureDfCount) + ", targetCount=" + str(tgtazureDfCount) + "]")
                    
                
                
                #delete_hdfs_folder(HDFS_BIN_PATH, hdfsPath)               

            except Exception as e:
                isError = True
                error = "exception occurred while working on table:[table=" + table['schema'] + "." + table['name'] + ", error=" + str(e) + "]"
                print(error)
                print(e)
                error_msg = error_msg + "\n" + error
                continue
        if isError:
            print("Error occured due to:"+error_msg)
            #send_error_mail(error_msg, appName, emailTo, emailFrom, smtpServer)
    finally:
        print("end")

    spark.stop()
