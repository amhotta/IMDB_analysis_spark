import sys
from random import random
from operator import add
import subprocess
from pyspark.sql import SparkSession
import requests;
from pyspark.sql.functions import col
import configparser
import argparse

azure_storage_api_base_url =  'https://intradotest.blob.core.windows.net/test'
hdfs_conf_file_location = "/databox_validation/validation.conf"
azure_root_container_name = "test"
azure_storage_account = "intradotest.blob.core.windows.net"
hdfs_name_node_base_url = "hdfs://localhost:9000"

def intersection(lst1, lst2):
    lst3 = [value for value in lst1 if value in lst2]
    return lst3

def run_cmd(args_list):
    print('Running system command: {0}'.format(' '.join(args_list)))
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    s_output, s_err = proc.communicate()
    s_return = proc.returncode
    return s_return, s_output, s_err


def readConfig(configFile):
    try:
        confParser = configparser.RawConfigParser(allow_no_value=True)
        confParser.read(configFile)
        return confParser
    except:
        print("Error: readConfig() was not successful:" + configFile)
        sys.exit(-1)

if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    # Required Arguments
    parser.add_argument('-a', '--app-conf',  dest = 'appConfFileLoc', help='app conf file', nargs='+')
    parser.add_argument('-t', '--tab-conf',  dest = 'tabConfFileLoc', help='table conf file', nargs='+')
    parser.add_argument('-e', '--envrionment',  dest = 'environment', help='environment', nargs='+')

    results = parser.parse_args()

    if results.appConfFileLoc is None or results.tabConfFileLoc is None or results.environment is None:
        parser.print_help()
        sys.exit(-1)

    mode = results.mode[0]
    appConfFileLoc = results.appConfFileLoc[0]
    tabConfFileLoc = results.tabConfFileLoc[0]
    environment = results.environment[0]

    print(appConfFileLoc)
    print(tabConfFileLoc)

    if environment != 'PREPROD' and environment != 'PROD':
        print("unknown environment")
        sys.exit(-1)


    config = readConfig(appConfFileLoc)
    hadoopHome = config[environment]['hadoopHome']
    storageAccountKey = config[environment]['storageAccountKey']
    storageAccount = config[environment]['storageAccount']
    containerName = config[environment]['storageContainer']
    num_mappers = config[environment]['numMappers']
    azjars = config[environment]['azjars']

    storageAccountAuth = "fs.azure.account.key." + storageAccount

    spark = SparkSession\
        .builder\
        .appName("databox_validation")\
        .getOrCreate()

    spark.conf.set(storageAccountAuth, storageAccountKey)

    tables = open(tabConfFileLoc, 'r')
    Lines = tables.readlines()

    count = 0
    # Strips the newline character
    tablesList = []
    for line in Lines:
        splits = line.strip().split("=")
        tableConf = {}.
        tableConf['name'] = splits[0]
        tableConf['hdfsLocation'] = splits[1]
        tablesList.append(tableConf)

    HDFS_BIN_PATH = hadoopHome  + '/bin/hdfs'

    df = spark.read.format("text").load("test/cimran0804/calllog_2021_08_04_13.log")
    df.selectExpr("split(value, ' ') as Text_Data").show(4, False)





    for table in tablesList:
        hdfs_folder_location = table['hdfsLocation']

        print("working on table:" + table['name'])
        (ret, out, err)= run_cmd([HDFS_BIN_PATH, 'dfs', '-ls', hdfs_folder_location + "/**" + "/" + "*.parquet"])
        if  err.strip() :
            print("There is an error during config file read:" + err.strip().decode("utf-8"))
        else :
            lines = out.decode("utf-8").split('\n')
            print(lines)
            for line in lines:
                if line.find(hdfs_folder_location) != -1:
                    cleansed = ' '.join(line.split())
                    print(cleansed)
                    file_path = cleansed.split(" ")[7]
                    print(file_path)
                    file_name = file_path.split("/")[6];
                    print("file_name:" + file_name)
                    print("*************** azure wasb **********************")
                    azureFileUrl = "wasb://"  + containerName + "@" + storageAccount + "/" + table['name'] + "/"  + file_name
                    azureDf = spark.read.parquet(azureFileUrl)
                    azureDfCount = azureDf.count()
                    print("azure df count:" + str(azureDfCount))
                    columns_from_azure = azureDf.columns
                    print("*************** hdfs **********************")
                    hdfsFile = hdfs_name_node_base_url + "/" + file_path
                    hdfsDf = spark.read.parquet(hdfsFile)
                    columns_from_hdfs = hdfsDf.columns
                    hdfsDfDfCount = hdfsDf.count()
                    print("hdfs count:" + str(hdfsDfDfCount))
                    if(hdfsDfDfCount == azureDfCount) :
                        print("count matched for :[hdfs_loc=" + hdfsFile +  "," +  "azureFileUrl=" + azureFileUrl + "]")
                    else:
                        print("count matched for :[hdfs_loc=" + hdfsFile +  "," +  "azureFileUrl=" + azureFileUrl + "]")
                    columns_from_azure.sort()
                    columns_from_hdfs.sort()
                    
                    if(columns_from_azure == columns_from_hdfs) :
                        print("columns matched for :[hdfs_loc=" + hdfsFile +  "," +  "azureFileUrl=" + azureFileUrl + "]")
                    else:
                        print("columns matched for :[hdfs_loc=" + hdfsFile +  "," +  "azureFileUrl=" + azureFileUrl + "]")

    spark.stop()
