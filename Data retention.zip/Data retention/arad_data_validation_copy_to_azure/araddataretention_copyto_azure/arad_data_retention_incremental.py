#! /usr/local/bin/python

import argparse
import subprocess
import sys
from datetime import date, timedelta
from re import sub

import requests
import logging
import os
import configparser
import time
import smtplib, traceback
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from impala.dbapi import connect

def backup_to_adls(HADOOP_BIN_PATH, filePath, fileName, tableName, storageAccountKey, storageAccount, containerName, num_mappers, azjars):
    azurePath = "wasb://" + containerName + "@" + storageAccount + "/" + tableName + "/" + fileName
    startTime = time.time()
    print("backing up partition to adls started [fileName=:" + fileName + ", table=" + tableName + ", hdfsPath=" + filePath + ",azurePath=" + azurePath + "]")

    (ret, out, err) = run_cmd(
            [HADOOP_BIN_PATH, 'distcp', '-Dfs.AbstractFileSystem.wasb.Impl=org.apache.hadoop.fs.azure.Wasb',
             '-Dfs.azure.account.key.' + storageAccount + '=' + storageAccountKey, '-libjars',
             azjars, '-m', num_mappers,
             filePath, "wasb://" + containerName + "@" + storageAccount + "/" + tableName + "/" + fileName])
    endTime = time.time()
    if ret == 0:
        print("backing up partition to adls completed successfully [fileName=:" + fileName + ", table=" + tableName + ", hdfsPath=" + filePath + ",azurePath=" + azurePath +
              ",timeTookInSecs=" + str((endTime-startTime)) + "]")
    else:
        print("error while copying using distcp [fileName=:" + fileName + ", table=" + tableName + ", hdfsPath=" + filePath + ",azurePath=" + azurePath + ", error=" + err.decode("utf-8") + "]")


def run_cmd(args_list):
    logging.info('Running system command: {0}'.format(' '.join(args_list)))
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    s_output, s_err = proc.communicate()
    s_return = proc.returncode
    return s_return, s_output, s_err

def read_hdfs_file(HDFS_BIN_PATH, hdfs_location) :
    (ret, out, err)= run_cmd([HDFS_BIN_PATH, 'dfs', '-cat', hdfs_location])
    print(ret)
    if ret == 0:
        return (ret, out, err)
    else:
        logging.error("There is an error during config file read:" + err.strip().decode("utf-8"))
        sys.exit(-1)

def readConfig(configFile):
    try:
        confParser = configparser.RawConfigParser(allow_no_value=True)
        confParser.read(configFile)
        return confParser
    except:
        print("Error: readConfig() was not successful:" + configFile)
        sys.exit(-1)

if __name__ == "__main__":
    tables = open('tables.conf', 'r')
    Lines = tables.readlines()

    count = 0
    # Strips the newline character
    tablesList = []
    for line in Lines:
        splits = line.strip().split("=")
        tableConf = {}
        tableConf['name'] = splits[0]
        tableConf['hdfsLocation'] = splits[1]
        tablesList.append(tableConf)

    print(tablesList)

    config = readConfig("app.conf")
    environment = "PROD"
    hadoopHome = config[environment]['hadoopHome']
    storageAccountKey = config[environment]['storageAccountKey']
    storageAccount = config[environment]['storageAccount']
    containerName = config[environment]['storageContainer']
    num_mappers = config[environment]['numMappers']
    azjars = config[environment]['azjars']

    HDFS_BIN_PATH = hadoopHome  + '/bin/hdfs'
    HADOOP_BIN_PATH = hadoopHome + '/bin/hadoop'
    print(HDFS_BIN_PATH)
    print(HADOOP_BIN_PATH)

    for table in tablesList:
        hdfsLocation = table['hdfsLocation']
        hdfsListFiles = hdfsLocation  + "**"  + "/" + "*.parquet"
        # print(hdfsLocation)
        (ret, out, err) = run_cmd([HDFS_BIN_PATH, 'dfs', '-ls', hdfsListFiles])
        print(ret)
        if ret == 0:
            lines = out.decode("utf-8").split("\n")
            print(lines)
            for line in lines:
                if line.find(hdfsLocation) != -1:
                    cleansed = ' '.join(line.split())
                    filePath = cleansed.split(" ")[7];
                    fileName = cleansed.split(" ")[7].split("/")[6];
                    print(filePath)
                    print(fileName)
                    backup_to_adls(HADOOP_BIN_PATH, filePath, fileName, table['name'], storageAccountKey,
                                       storageAccount, containerName, num_mappers, azjars);
        else:
            print("error while getting files information  from hdfs path [hdfsPath=" + hdfsLocation + ", error=" + err.decode(
                        "utf-8") + "]")



